import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RETURN here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RETURN extends Boton
{
    public RETURN()
    {
    GreenfootImage R = new GreenfootImage ("REG.png");
    setImage(R);
    }
    public void act() 
    {
        checkMouse();
        checkClick(new Menu());
    }      
}
