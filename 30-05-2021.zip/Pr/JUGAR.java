import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class JUGAR here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class JUGAR extends Boton
{
    public JUGAR()
    {
    GreenfootImage playButton = new GreenfootImage ("JUGAR.png");
    setImage(playButton);
    }
 
    public void act() 
    {
        checkMouse();
        checkClick(new Nivel1());
    }    
}
