import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 Proyectiles que se disparan, dependiendo del actor, mostrara un proyectil de diferente color 
 para permitir diferenciar entre actores (Enemigo,jugador)
 */
public class proyectil extends Actor
{
    int TiempoVivo; // Aun no encuentro relacion con tiempo real en ms
    int Trayectoria; //Alterna entre 8 trayectorias: 1->Arriba 2->Arriba-Derecha 3->Derecha 4->Derecha-Abajo 5->Abajo 6->Abajo-Izquierda 7->Izquierda 8->Arriba-Izquierda
    int Propietario; // 1->Jugador , 2->Enemigo Comun ... 3->Enemigo Especial? ... 4->...
    
    
    /**
     * Act - do whatever the proyectil wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        movProyectil();
    } 
    public proyectil(int i, int p) //Recibe i (una de las 8 trayectorias disp.) y p (A quien pertenece el proyectil)
    {
        Trayectoria = i;
        TiempoVivo = 100;
        Propietario = p;
        switch(p){
            case 1: setImage("blue-draught.png"); // Si p es igual a 1, indica que es perteneciente al jugador y lo dibuja como un circulo azul el objeto.
        }
    }
    public void movProyectil()
    {
    if(TiempoVivo > 0)
    {
     switch(Trayectoria)
     {
        case 1: setLocation (getX(), getY()-5); TiempoVivo--; break;
        case 2: setLocation (getX()+4, getY()-4); TiempoVivo--; break;
        case 3: setLocation (getX()+5, getY()); TiempoVivo--; break;
        case 4: setLocation (getX()+4, getY()+4); TiempoVivo--; break;
        case 5: setLocation (getX(), getY()+5); TiempoVivo--; break;
        case 6: setLocation (getX()-4, getY()+4); TiempoVivo--; break;
        case 7: setLocation (getX()-5, getY()); TiempoVivo--; break;
        case 8: setLocation (getX()-4, getY()-4); TiempoVivo--; break;
        
     }
    }
    else{eliminar();} //Una vez expirado su tiempo de vida se elimina
    }
    public void eliminar()
    {
    // El recolector de basura de Java se encarga de eliminar el objeto.
    
    }
}
