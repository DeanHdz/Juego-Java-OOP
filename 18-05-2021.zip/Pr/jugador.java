import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class jugador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class jugador extends Actor
{
 public int Vida;
 public int TearDelay;
 public jugador()
 {
    Vida=100;
    TearDelay=0;
 }

 public void act() 
    {
      disparaproyectil();
      moveAround();
    }   
    
 public void moveAround()
 {
     
   if(Greenfoot.isKeyDown("D") && Greenfoot.isKeyDown("A")) // Si ambos estan presionados se ignoran y prosigue a comparar las teclas de arriba y abajo
    { 
    if(Greenfoot.isKeyDown("W") && Greenfoot.isKeyDown("S")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        if(Greenfoot.isKeyDown("W")){setLocation(getX(),getY()-5);} //En el caso de que solo la tecla de arriba esta presionada
        else if (Greenfoot.isKeyDown("S")){setLocation(getX(),getY()+5);} // En el caso de que solo abajo esta presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("W") && Greenfoot.isKeyDown("S")){
    if(Greenfoot.isKeyDown("D") && Greenfoot.isKeyDown("A")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        if(Greenfoot.isKeyDown("D")){setLocation(getX()+5,getY());} //En el caso de que solo la tecla de der. esta presionada
        else if(Greenfoot.isKeyDown("A")){setLocation(getX()-5,getY());} //Solo izq presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("W") && Greenfoot.isKeyDown("D")){
        setLocation(getX()+4,getY()-4);
    }
    
    else if(Greenfoot.isKeyDown("D") && Greenfoot.isKeyDown("S")){
        setLocation(getX()+4,getY()+4);
    }
    
    else if(Greenfoot.isKeyDown("S") && Greenfoot.isKeyDown("A")){
        setLocation(getX()-4,getY()+4);
    }
    
    else if(Greenfoot.isKeyDown("A") && Greenfoot.isKeyDown("W")){
        setLocation(getX()-4,getY()-4);
    }
    
    else if(Greenfoot.isKeyDown("W")){
        setLocation(getX(),getY()-5);
    }
    
    else if(Greenfoot.isKeyDown("A")){
        setLocation(getX()-5,getY());
    }
    
    else if(Greenfoot.isKeyDown("S")){
        setLocation(getX(),getY()+5);
    }
    
    else if(Greenfoot.isKeyDown("D")){
        setLocation(getX()+5,getY());
    }  
     
 }

 public void disparaproyectil()
 {
   if(TearDelay == 0)
   {
    TearDelay = 10;
    
    if(Greenfoot.isKeyDown("right") && Greenfoot.isKeyDown("left")) // Si ambos estan presionados se ignoran y prosigue a comparar las teclas de arriba y abajo
    { 
    if(Greenfoot.isKeyDown("up") && Greenfoot.isKeyDown("down")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        if(Greenfoot.isKeyDown("up")){getWorld().addObject(new proyectil(1,1), getX(), getY());} //En el caso de que solo la tecla de arriba esta presionada
        else if (Greenfoot.isKeyDown("down")){getWorld().addObject(new proyectil(5,1), getX(), getY());} // En el caso de que solo abajo esta presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("up") && Greenfoot.isKeyDown("down")){
    if(Greenfoot.isKeyDown("right") && Greenfoot.isKeyDown("left")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        if(Greenfoot.isKeyDown("right")){getWorld().addObject(new proyectil(3,1), getX(), getY());} //En el caso de que solo la tecla de der. esta presionada
        else if(Greenfoot.isKeyDown("left")){getWorld().addObject(new proyectil(7,1), getX(), getY());} //Solo izq presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("up") && Greenfoot.isKeyDown("right")){
        getWorld().addObject(new proyectil(2,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("right") && Greenfoot.isKeyDown("down")){
        getWorld().addObject(new proyectil(4,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("down") && Greenfoot.isKeyDown("left")){
        getWorld().addObject(new proyectil(6,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("left") && Greenfoot.isKeyDown("up")){
        getWorld().addObject(new proyectil(8,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("up")){
        getWorld().addObject(new proyectil(1,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("right")){
        getWorld().addObject(new proyectil(3,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("down")){
        getWorld().addObject(new proyectil(5,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("left")){
        getWorld().addObject(new proyectil(7,1), getX(), getY());
    }
    
   }
   else
   {
    this.TearDelay--;
   }
 }


 public void MuestraVida()
 {
    String v = String.valueOf(this.Vida);
    //getBackground().drawImage(new GreenfootImage(v, 64, null, null), 40, 40);
 }
}

