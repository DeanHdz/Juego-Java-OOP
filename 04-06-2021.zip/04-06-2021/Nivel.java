import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList; // import the ArrayList class
/**
 * Write a description of class Nivel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nivel extends World
{
    int NumNivel;
    int enemigosTotales;
    Room CurrentRoom;
    public Nivel(int NumNivel)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        this.NumNivel = NumNivel;
        switch(NumNivel)
        {
         case 1: setBackground("Nivel_1.png");
         createRooms(); Inicia(); break;
         case 2: setBackground("Nivel_1.png"); // CAMBIAR EL SPRITE AL FONDO TEMATICO DEL NIVEL 2!!!!
         createRooms(); Inicia(); break;
         case 3: setBackground("Nivel_1.png"); // CAMBIAR EL SPRITE AL FONDO TEMATICO DEL NIVEL 3!!!!
         createRooms(); Inicia(); break;
        }
    }
    
    public void createRooms()
    {
        // Funcion para crear los cuartos de acuerdo al nivel, el cuarto "uno" es el inicio y el "diez" es el jefe
        // "Room->numeroDeCuarto_numeroDeNivel
        switch(NumNivel)
        {
         case 1: Room uno_1,dos_1,tres_1,cuatro_1,cinco_1,seis_1,siete_1,ocho_1,nueve_1,diez_1;
         uno_1 = new Room(this.NumNivel,1); 
         dos_1 = new Room(this.NumNivel,2); 
         tres_1 = new Room(this.NumNivel,3); 
         cuatro_1 = new Room(this.NumNivel,4); 
         cinco_1 = new Room(this.NumNivel,5);
         seis_1 = new Room(this.NumNivel,6);
         siete_1 = new Room(this.NumNivel,7);
         ocho_1 = new Room(this.NumNivel,8);
         nueve_1 = new Room(this.NumNivel,9);
         diez_1 = new Room(this.NumNivel,10);
         
         uno_1.setExits(null,null,null,dos_1);
         dos_1.setExits(null,uno_1,tres_1,cuatro_1);
         tres_1.setExits(dos_1,null,null,null);
         cuatro_1.setExits(cinco_1,dos_1,null,seis_1);
         cinco_1.setExits(null,null,cuatro_1,null);
         seis_1.setExits(null,cuatro_1,siete_1,null);
         siete_1.setExits(seis_1,null,ocho_1,null);
         ocho_1.setExits(siete_1,null,nueve_1,null);
         nueve_1.setExits(ocho_1,null,diez_1,null);
         diez_1.setExits(null,null,nueve_1,null);
         
         this.CurrentRoom = uno_1; break;
         
         case 2: Room uno_2,dos_2,tres_2,cuatro_2,cinco_2,seis_2,siete_2,ocho_2,nueve_2,diez_2;
         uno_2 = new Room(this.NumNivel,1); 
         dos_2 = new Room(this.NumNivel,2); 
         tres_2 = new Room(this.NumNivel,3); 
         cuatro_2 = new Room(this.NumNivel,4); 
         cinco_2 = new Room(this.NumNivel,5);
         seis_2 = new Room(this.NumNivel,6);
         siete_2 = new Room(this.NumNivel,7);
         ocho_2 = new Room(this.NumNivel,8);
         nueve_2 = new Room(this.NumNivel,9);
         diez_2 = new Room(this.NumNivel,10);
         
         uno_2.setExits(dos_2,null,cuatro_2,tres_2);
         dos_2.setExits(null,null,uno_2,null);
         tres_2.setExits(uno_2,null,null,null);
         cuatro_2.setExits(uno_2,cinco_2,null,null);
         cinco_2.setExits(seis_2,null,siete_2,cuatro_2);
         seis_2.setExits(null,null,cinco_2,null);
         siete_2.setExits(cinco_2,nueve_2,ocho_2,null);
         ocho_2.setExits(siete_2,null,null,null);
         nueve_2.setExits(null,diez_2,null,siete_2);
         diez_2.setExits(null,null,null,nueve_2);
         
         this.CurrentRoom = uno_2; break;
         
         case 3: Room uno_3,dos_3,tres_3,cuatro_3,cinco_3,seis_3,siete_3,ocho_3,nueve_3,diez_3;
         uno_3 = new Room(this.NumNivel,1); 
         dos_3 = new Room(this.NumNivel,2); 
         tres_3 = new Room(this.NumNivel,3); 
         cuatro_3 = new Room(this.NumNivel,4); 
         cinco_3 = new Room(this.NumNivel,5);
         seis_3 = new Room(this.NumNivel,6);
         siete_3 = new Room(this.NumNivel,7);
         ocho_3 = new Room(this.NumNivel,8);
         nueve_3 = new Room(this.NumNivel,9);
         diez_3 = new Room(this.NumNivel,10);
         
         uno_3.setExits(null,cinco_3,dos_3,tres_3);
         dos_3.setExits(uno_3,null,null,null);
         tres_3.setExits(null,uno_3,null,cuatro_3);
         cuatro_3.setExits(null,tres_3,null,null);
         cinco_3.setExits(seis_3,siete_3,null,uno_3);
         seis_3.setExits(null,null,cinco_3,null);
         siete_3.setExits(null,nueve_3,ocho_3,cinco_3);
         ocho_3.setExits(siete_3,null,null,null);
         nueve_3.setExits(null,diez_3,null,siete_3);
         diez_3.setExits(null,null,null,nueve_3);
         
         this.CurrentRoom = uno_3; break;
        }
    }
    
    private void Inicia()
    {   
        
        addObject(new Vida(),140,40); //Se aniaden los objetos de vida en el mapa.
        addObject(new Vida(),90,40);
        addObject(new Vida(),40,40);

        addObject(new Jugador(),Greenfoot.getRandomNumber(60)+40,Greenfoot.getRandomNumber(300)+70);
        aparicionEnemigos(CurrentRoom.RoomID); //Aparecer enemigos segun el nivel, se empieza en el nivel = 1;

        addObject(new ContadorSeconds(),670,40); //Se establecer los contadores de tiempo
        addObject(new Contador10Seconds(),590,40);
        addObject(new Contador100Seconds(),530,40);
        
        printDoors();

    }
    
    public void aparicionEnemigos(int roomID){
        
        if(CurrentRoom.TieneEnemigos==true){
        switch(roomID){ //Se realiza un switch segun el cuarto en que se encuentre el jugador. 
            case 1:
            enemigosTotales = aparecerEnemigoNVecer(1, 0);
            break;
            case 2: 
            enemigosTotales = aparecerEnemigoNVecer(0, 1);
            break;
            case 3:
            enemigosTotales = aparecerEnemigoNVecer(1, 1);
            break;
            case 4:
            enemigosTotales = aparecerEnemigoNVecer(1, 2);
            break;
            case 5:
            enemigosTotales = aparecerEnemigoNVecer(2, 2);
            break;
            case 6:
            enemigosTotales = aparecerEnemigoNVecer(2, 2);
            break;
            case 7:
            enemigosTotales = aparecerEnemigoNVecer(3, 2);
            break;
            case 8:
            enemigosTotales = aparecerEnemigoNVecer(3, 2);
            break;
            case 9:
            enemigosTotales = aparecerEnemigoNVecer(3, 3);
            break;
            case 10:
            enemigosTotales = aparecerEnemigoNVecer(3, 3);
            break;
        }
    }
    
    } 
    
    public int aparecerEnemigoNVecer(int n, int m){
        for(int i=0; i<n; i++){
            addObject(new Enemigo("E1"),Greenfoot.getRandomNumber(350)+200,Greenfoot.getRandomNumber(320)+40);  
        }
        for(int i=0; i<m; i++){
            addObject(new Enemigo("E2"),Greenfoot.getRandomNumber(350)+200,Greenfoot.getRandomNumber(320)+40);

        }
        return n+m;
    }
    
    public void decrementarEnemigos(){
        enemigosTotales--;
        if(enemigosTotales == 0){
            CurrentRoom.TieneEnemigos = false;
        }
    }
    
    public void printDoors()
    {
        if(enemigosTotales == 0)
        {
         if(CurrentRoom.northExit != null)
         {addObject(new Door(1,0),400,30); }
         if(CurrentRoom.eastExit != null)
         {addObject(new Door(1,1),30,300); }
         if(CurrentRoom.southExit != null)
         {addObject(new Door(1,2),400,570); }
         if(CurrentRoom.westExit != null)
         {addObject(new Door(1,3),770,300); }
        }
        else
        {
         if(CurrentRoom.northExit != null)
         {addObject(new Door(0,0),400,30); }
         if(CurrentRoom.eastExit != null)
         {addObject(new Door(0,1),30,300); }
         if(CurrentRoom.southExit != null)
         {addObject(new Door(0,2),400,570); }
         if(CurrentRoom.westExit != null)
         {addObject(new Door(0,3),770,300); }  
        }
    }
    
    public void cambiarRoom()
    {
        
    }
    
}
