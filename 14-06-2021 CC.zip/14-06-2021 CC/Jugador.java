 import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class jugador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Jugador extends Actor
{
 public int vida;
 public int tearDelay;
 List<Vida> listaVidas;
 public GreenfootSound music = new GreenfootSound("level music.mp3"); 
 public Jugador()
 {
    vida=3;
    tearDelay=0;
 }

 public void act() 
    {
      disparaproyectil();
      moveAround();
      generarListaDeVidas();
      music.play();
    }   
    
 public void moveAround()
 {
     
   if(Greenfoot.isKeyDown("D") && Greenfoot.isKeyDown("A")) // Si ambos estan presionados se ignoran y prosigue a comparar las teclas de arriba y abajo
    { 
    if(Greenfoot.isKeyDown("W") && Greenfoot.isKeyDown("S")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        if(Greenfoot.isKeyDown("W")){
            setImage("back.png");
            isShootingSetImage();
            setLocation(getX(),getY()-5);} //En el caso de que solo la tecla de arriba esta presionada
        else if (Greenfoot.isKeyDown("S")){
            setImage("front.png");
            isShootingSetImage();
            setLocation(getX(),getY()+5);} // En el caso de que solo abajo esta presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("W") && Greenfoot.isKeyDown("S")){
    if(Greenfoot.isKeyDown("D") && Greenfoot.isKeyDown("A")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        if(Greenfoot.isKeyDown("D")){
            setImage("right.png");
            isShootingSetImage(); 
            setLocation(getX()+5,getY());} //En el caso de que solo la tecla de der. esta presionada
        else if(Greenfoot.isKeyDown("A")){
            setImage("left.png");
            isShootingSetImage();
            setLocation(getX()-5,getY());} //Solo izq presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("W") && Greenfoot.isKeyDown("D")){
        setImage("right.png");
        isShootingSetImage();
        setLocation(getX()+4,getY()-4);
    }
    
    else if(Greenfoot.isKeyDown("D") && Greenfoot.isKeyDown("S")){
        setImage("right.png");
        isShootingSetImage();
        setLocation(getX()+4,getY()+4);
    }
    
    else if(Greenfoot.isKeyDown("S") && Greenfoot.isKeyDown("A")){
        setImage("left.png");
        isShootingSetImage();
        setLocation(getX()-4,getY()+4);
    }
    
    else if(Greenfoot.isKeyDown("A") && Greenfoot.isKeyDown("W")){
        setImage("left.png");
        isShootingSetImage();
        setLocation(getX()-4,getY()-4);
    }
    
    else if(Greenfoot.isKeyDown("W")){
        setImage("back.png");
        isShootingSetImage();
        setLocation(getX(),getY()-5);
    }
    
    else if(Greenfoot.isKeyDown("A")){
        setImage("left.png");
        isShootingSetImage();
        setLocation(getX()-5,getY());
    }
    
    else if(Greenfoot.isKeyDown("S")){
        setImage("front.png");
        isShootingSetImage();
        setLocation(getX(),getY()+5);
    }
    
    else if(Greenfoot.isKeyDown("D")){
        setImage("right.png");
        isShootingSetImage();
        setLocation(getX()+5,getY());
    }  
     
 }
 
 public void isShootingSetImage(){
     // Esta clase cambia de imagen si es que el jugador esta disparando, este cambia segun la direccion del proyectil.
    if(Greenfoot.isKeyDown("up")){
            setImage("back.png");
            } else if(Greenfoot.isKeyDown("down")){
            setImage("front.png");
            } else if(Greenfoot.isKeyDown("right")){
            setImage("right.png");
            } else if(Greenfoot.isKeyDown("left")){
            setImage("left.png");
            }
 }
 
 public void disparaproyectil()
 {
   if(tearDelay == 0)
   {
    
    if(Greenfoot.isKeyDown("right") && Greenfoot.isKeyDown("left")) // Si ambos estan presionados se ignoran y prosigue a comparar las teclas de arriba y abajo
    { 
    if(Greenfoot.isKeyDown("up") && Greenfoot.isKeyDown("down")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        if(Greenfoot.isKeyDown("up")){
            setImage("sb.png");
            Greenfoot.playSound("pew.mp3");
            getWorld().addObject(new Proyectil(1,1), getX(), getY());} //En el caso de que solo la tecla de arriba esta presionada
        else if (Greenfoot.isKeyDown("down")){
            setImage("sf.png");
            Greenfoot.playSound("pew.mp3");
            getWorld().addObject(new Proyectil(5,1), getX(), getY());} // En el caso de que solo abajo esta presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("up") && Greenfoot.isKeyDown("down")){
    if(Greenfoot.isKeyDown("right") && Greenfoot.isKeyDown("left")){} // Si ambos tambien estan presionados, entonces no dispara.
    else{
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        if(Greenfoot.isKeyDown("right")){
            setImage("sr.png");
            Greenfoot.playSound("pew.mp3");
            getWorld().addObject(new Proyectil(3,1), getX(), getY());} //En el caso de que solo la tecla de der. esta presionada
        else if(Greenfoot.isKeyDown("left")){
            setImage("sl.png");
            Greenfoot.playSound("pew.mp3");
            getWorld().addObject(new Proyectil(7,1), getX(), getY());} //Solo izq presionado
    }
    }
    
    else if(Greenfoot.isKeyDown("up") && Greenfoot.isKeyDown("right")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sr.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(2,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("right") && Greenfoot.isKeyDown("down")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sr.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(4,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("down") && Greenfoot.isKeyDown("left")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sl.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(6,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("left") && Greenfoot.isKeyDown("up")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sl.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(8,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("up")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sb.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(1,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("right")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sr.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(3,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("down")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sf.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(5,1), getX(), getY());
    }
    
    else if(Greenfoot.isKeyDown("left")){
        tearDelay = 7; //Cantidad de tiempo a esperar una vez disparado
        setImage("sl.png");
        Greenfoot.playSound("pew.mp3");
        getWorld().addObject(new Proyectil(7,1), getX(), getY());
    }
    
   }
   else
   {
    this.tearDelay--;
   }
 }

 public void generarListaDeVidas(){
    listaVidas = getWorld().getObjects(Vida.class);  
      
 }
 
 public void eliminaUnaVida(){
        for (Object obj: listaVidas) //for each element in the list
    {
    Vida cn = (Vida) obj; //cast the object, so you can use the 'isUsed' variable
    if (cn != null) getWorld().removeObject(cn); //without 'getWorld' if it is used in a world subclass
    break; //if 'isUsed' isn't public, call the getter method instead
    }
 }
 
 public void diminuyeVidaJugador()
 {
    vida = vida - 1; //Si un enemigo toca al jugador, se le disminuye la vida en 20;
    if(vida>=0){
        eliminaUnaVida();
    }
    setLocation(0,0); //Se realiza un respawn al objeto.
    if(vida <=0){
       music.stop();
        getWorld().removeObject(this);
       Greenfoot.setWorld(new GAMEOVER());
    } // Si la vida es menor o igual a 0, entonces se elimina el objeto y acaba el juego. 
    
 }
 
}

