import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SALIR here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SALIR extends Boton
{
    public SALIR()
    {
    GreenfootImage S = new GreenfootImage ("SALIR.png");
    setImage(S);
    }
    public void act() 
    {
     checkMouse();
        if(Greenfoot.mouseClicked(this))
    {
     Greenfoot.stop();
    }
    } 
}
