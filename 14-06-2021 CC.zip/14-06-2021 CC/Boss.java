import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 * Write a description of class Boss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss extends Actor
{
    private int posicionJugador[] = {0,0};
    private int posicionBoss[] = {0,0};
    private int vida = 0;
    private int resetImageCounter = 0;

    String nombre;
    
    /**
     * Act - do whatever the Boss wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
      
    public Boss(String nombre){
        this.nombre = nombre ; //Se asigna el String principal del nombre de la imagen del Boss
        setImage(nombre + ".png"); // Se implementa la imagen .png
        this.vida = 100; //Se establecen las vidas iniciales del Boss
        this.resetImageCounter = 100; //Contador para volver a setear la imagen del boss
    }
    
    public void act() 
    {
        followCharacter();  
    }    
    
    public void followCharacter(){
        
        // Funcion para realizar el seguimiento al jugador principal (El Boss debe de seguir al personaje principal)
        try{
        Jugador player = (Jugador) getWorld().getObjects(Jugador.class).get(0);
        
        this.resetImageCounter = this.resetImageCounter - 18;
        if(this.resetImageCounter <= 0){
            setImage(nombre + ".png"); //Se hace un set a la imagen para que vuelva al estado original
         }
        if (player != null){
            
            for(int i = 0; i<3; i++){
               posicionJugador[0] = player.getX(); //Se guarda la posicion en X del jugador
               posicionJugador[1] = player.getY(); //Se guarda la posicion en Y del jugador
               posicionBoss[0] = getX(); //Se guarda la posicion en X del Boss
               posicionBoss[1] = getY(); ////Se guarda la posicion en Y del Boss
               if((Math.abs(posicionJugador[0]-posicionBoss[0])) > 20 ||  (Math.abs(posicionJugador[1]-posicionBoss[1])) > 20){ // Se analiza si el jugador se encuentra a distancia suficiente de los Bosss para que no le quiten vida .
                   if(posicionBoss[0]>posicionJugador[0]){
                   if(posicionBoss[1]>posicionJugador[1]){
                       setLocation(getX()-1,getY()-1); //El Boss se encuentra abajo a la derecha;
                   } else if(posicionBoss[1]<posicionJugador[1]){
                       setLocation(getX()-1,getY()+1); //El Boss se encuentra arriba a la derecha
                   } else {
                       setLocation(getX()-1,getY()); // El Boss se encuentra a la derecha
                   }
               } else if(posicionBoss[0]<posicionJugador[0]){
                   if(posicionBoss[1]>posicionJugador[1]){
                       setLocation(getX()+1,getY()-1); //El Boss se encuentra abajo a la izquierda;
                   } else if(posicionBoss[1]<posicionJugador[1]){
                       setLocation(getX()+1,getY()+1); //El Boss se encuentra arriba a la izquierda
                   } else {
                       setLocation(getX()+1,getY()); //El Boss se encuentra a la izquierda
                   }
               } else if(posicionBoss[0]==posicionJugador[0]){
                   if(posicionBoss[1]>posicionJugador[1]){
                       setLocation(getX(),getY()-1); //El Boss se encuentra abajo a la izquierda;
                   } else if(posicionBoss[1]<posicionJugador[1]){
                       setLocation(getX(),getY()+1); //El Boss se encuentra arriba a la izquierda
                   } else {
                       player.diminuyeVidaJugador();
                   }
               }
                   
               } else {
               player.diminuyeVidaJugador();
              }
              
            }
        }        
        } catch(Exception e){
            return;
        }
        
    }
    
 
 public void diminuyeVida()
 {
    if(vida <=1){  
        setImage(nombre + "-death.png"); // Se hace el set a la imagen de boss muerto.
        Greenfoot.delay(150); //Se hace un delay para que se vea que murio el enemigo
        getWorld().removeObject(this); // Se destruye el objeto
        //((Nivel)getWorld()).SigNivel(); //Aumenta el nivel en la clase nivel. 
    } 
    setImage(nombre + "-shoot.png");
    this.resetImageCounter = 100;
    vida--;
    
    
    //Si un Boss toca al jugador, se le disminuye la vida en 20;
    
    // Si la vida es menor o igual a 0, entonces se elimina el objeto y acaba el juego. 
    
    //TODO: Regresar al menu principal.
    
 }
 
 public int getVida(){
     return vida;
 }
}



