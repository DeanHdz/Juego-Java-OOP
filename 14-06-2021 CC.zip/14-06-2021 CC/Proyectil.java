import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 Proyectiles que se disparan, dependiendo del actor, mostrara un proyectil de diferente color 
 para permitir diferenciar entre actores (Enemigo,jugador)
 */
public class Proyectil extends Actor
{
    int tiempoVivo; // Aun no encuentro relacion con tiempo real en ms
    int trayectoria; //Alterna entre 8 trayectorias: 1->Arriba 2->Arriba-Derecha 3->Derecha 4->Derecha-Abajo 5->Abajo 6->Abajo-Izquierda 7->Izquierda 8->Arriba-Izquierda
    int propietario; // 1->Jugador , 2->Enemigo Comun ... 3->Enemigo Especial? ... 4->...
    int posicion[] = {0,0};// Prosicion del Proyectil
    
    /**
     * Act - do whatever the proyectil wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    

    
    public void act() 
    {
        movProyectil();
     } 
     
    public Proyectil(int i, int p) //Recibe i (una de las 8 trayectorias disp.) y p (A quien pertenece el proyectil)
    {
        trayectoria = i;
        tiempoVivo = 100;
        propietario = p;
        switch(p){
            case 1: 
               // Si p es igual a 1, indica que es perteneciente al jugador y lo dibuja como un circulo azul el objeto.
                getImage().scale(getImage().getWidth() - 13, getImage().getHeight() - 13);
            }
    }
    
    public void movProyectil()
    {
    if(tiempoVivo > 0)
    {
     switch(trayectoria)
     {
        case 1: setLocation (getX(), getY()-4); tiempoVivo--; 
        setImage("p up.png");break;
        case 2: setLocation (getX()+4, getY()-4); tiempoVivo--;
        setImage("p right.png");break;
        case 3: setLocation (getX()+5, getY()); tiempoVivo--; 
        setImage("p right.png"); break;
        case 4: setLocation (getX()+4, getY()+4); tiempoVivo--; 
        setImage("p right.png"); break;
        case 5: setLocation (getX(), getY()+5); tiempoVivo--;
        setImage("p down.png");break;
        case 6: setLocation (getX()-4, getY()+4); tiempoVivo--;
        setImage("p left.png");break;
        case 7: setLocation (getX()-5, getY()); tiempoVivo--;
        setImage("p left.png");break;
        case 8: setLocation (getX()-4, getY()-4); tiempoVivo--;
        setImage("p left.png");break;
      
     }
     posicion[0] = getX(); //Se obtiene la posicion en x del proyectil
     posicion[1] = getY(); // Se obtiene la posicion en y del proyectil
     proyectilChoca(); // Si el proyectil choca con con la pared o un proyectil, entonces el objeto proyectil desaparece. 
     proyectilChocaBoss();
     
    }
    else{eliminar();} //Una vez expirado su tiempo de vida se elimina
    }
    
    public void proyectilChoca(){
        try{
        Enemigo en = (Enemigo) getOneIntersectingObject(Enemigo.class);
        if(tiempoVivo == 0 || (posicion[0] < 1) || (posicion[0]>794) || (posicion[1]<1) || (posicion[1]>594)){
         //Si el proyectil tiene un Tiempo vivo igual a 0, se elimina el objeto
         //Si la posicion del proyectil esta cerca de x = 0 o x = 400 en un rango de +-6, el objeto elimina
         //Si la posicion del proyectil esta cerca de y = 0 o y = 600 en un rango de +-6, el objeto elimina
         
         eliminar();
         return;
        } else if(((Math.abs(en.getX()-getX())<9)&&(Math.abs(en.getX()-getX())>0)) || ((Math.abs(en.getY()-getY())<9)&&(Math.abs(en.getY()-getY())>0))){
            eliminar(); //Se elimina el proyectil si este choca con algun enemigo
            en.diminuyeVida(); //El enemigo disminuye de vida en 1, el tiene 3. si llega a 0 su vida, entonces remueve el objeto dentro del metodo disminuye vida.   
            return;
        } 
        
        } catch(Exception e){
            return;
        }
        
        if(tiempoVivo == 0 || (posicion[0] < 1) || (posicion[0]>794) || (posicion[1]<1) || (posicion[1]>594)){
         //Si el proyectil tiene un Tiempo vivo igual a 0, se elimina el objeto
         //Si la posicion del proyectil esta cerca de x = 0 o x = 400 en un rango de +-6, el objeto elimina
         //Si la posicion del proyectil esta cerca de y = 0 o y = 600 en un rango de +-6, el objeto elimina
         
         eliminar();
        }
    }
    
    public void proyectilChocaBoss(){
        try{
        Boss en = (Boss) getOneIntersectingObject(Boss.class);
        if(tiempoVivo == 0 || (posicion[0] < 1) || (posicion[0]>794) || (posicion[1]<1) || (posicion[1]>594)){
         //Si el proyectil tiene un Tiempo vivo igual a 0, se elimina el objeto
         //Si la posicion del proyectil esta cerca de x = 0 o x = 400 en un rango de +-6, el objeto elimina
         //Si la posicion del proyectil esta cerca de y = 0 o y = 600 en un rango de +-6, el objeto elimina
         
         eliminar();
         return;
        } else if(((Math.abs(en.getX()-getX())<9)&&(Math.abs(en.getX()-getX())>0)) || ((Math.abs(en.getY()-getY())<9)&&(Math.abs(en.getY()-getY())>0))){
            eliminar(); //Se elimina el proyectil si este choca con algun enemigo
            en.diminuyeVida(); //El enemigo disminuye de vida en 1, el tiene 3. si llega a 0 su vida, entonces remueve el objeto dentro del metodo disminuye vida.   
            return;
        } 
        
        } catch(Exception e){
            return;
        }
        
        if(tiempoVivo == 0 || (posicion[0] < 1) || (posicion[0]>794) || (posicion[1]<1) || (posicion[1]>594)){
         //Si el proyectil tiene un Tiempo vivo igual a 0, se elimina el objeto
         //Si la posicion del proyectil esta cerca de x = 0 o x = 400 en un rango de +-6, el objeto elimina
         //Si la posicion del proyectil esta cerca de y = 0 o y = 600 en un rango de +-6, el objeto elimina
         
         eliminar();
        }
    }
    
    public void eliminar() //Elimina el proyectil una vez terminado su tiempo de vida o chocado con un muro/enemigo
    {
    getWorld().removeObject(this);
    }
}
