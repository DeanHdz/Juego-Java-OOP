import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class INSTRUCCIONS here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class INSTRUCCIONS extends Boton
{
    public INSTRUCCIONS()
    {
    GreenfootImage CJ = new GreenfootImage ("COMO-JUGAR.png");
    setImage(CJ);
    }
    public void act() 
    {
        checkMouse();
        checkClick(new Instrucciones());
    }    
}
