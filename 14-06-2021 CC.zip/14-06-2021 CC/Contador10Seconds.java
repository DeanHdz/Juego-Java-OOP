import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class contador10Seconds here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Contador10Seconds extends ContadorTiempo
{
    /**
     * Act - do whatever the contador10Seconds wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Contador10Seconds(){
    
    }
    
    public void act() 
    {
        setImage((getAgeInSeconds()/10)%10 + ".png");// Add your action code here.
    }    
}
