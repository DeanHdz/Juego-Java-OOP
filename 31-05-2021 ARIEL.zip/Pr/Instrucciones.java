import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Instrucciones here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Instrucciones extends World
{

    /**
     * Constructor for objects of class Instrucciones.
     * 
     */
    public Instrucciones()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 520, 1); 
        prepare();
    }


    private void prepare()
    {

        RETURN xreturn = new RETURN();
        addObject(xreturn,591,752);
        xreturn.setLocation(596,458);
        xreturn.setLocation(592,466);
    }

}
