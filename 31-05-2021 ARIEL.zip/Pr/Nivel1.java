import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nivel1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nivel1 extends World
{

    /**
     * Constructor for objects of class Nivel1.
     * 
     */
    int nivel = 1; // 
    int enemigosTotales = 0;

    public Nivel1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1);
        Inicia();
        prepare();
    }

    private void Inicia()
    {   
        addObject(new Vida(),140,40); //Se aniaden los objetos de vida en el mapa.
        addObject(new Vida(),90,40);
        addObject(new Vida(),40,40);

        addObject(new Jugador(),Greenfoot.getRandomNumber(60)+40,Greenfoot.getRandomNumber(300)+70);
        aparicionEnemigos(nivel); //Aparecer enemigos segun el nivel, se empieza en el nivel = 1;

        addObject(new ContadorSeconds(),670,40); //Se establecer los contadores de tiempo
        addObject(new Contador10Seconds(),530,40);
        addObject(new Contador100Seconds(),590,40);

    }

    public void incrementarNivel(){
        nivel++;
    }

    public void decrementarEnemigos(){

        enemigosTotales--;
        if(enemigosTotales == 0){
            incrementarNivel();
            aparicionEnemigos(nivel);
        }
    }

    public void aparicionEnemigos(int nivel){

        switch(nivel){ //Se realiza un switch segun el nivel en que se encuentre el jugador. 
            case 1:
            enemigosTotales = aparecerEnemigoNVecer(1, 0);
            break;
            case 2:
            setBackground(new GreenfootImage("SALIR.png")); //TODO: Definir las imagenes de fondo para cada uno de los niveles. 
            enemigosTotales = aparecerEnemigoNVecer(0, 1);
            break;
            case 3:
            enemigosTotales = aparecerEnemigoNVecer(1, 1);
            break;
            case 4:
            enemigosTotales = aparecerEnemigoNVecer(1, 2);
            break;
            case 5:
            enemigosTotales = aparecerEnemigoNVecer(2, 2);
            break;
            case 6:
            enemigosTotales = aparecerEnemigoNVecer(2, 2);
            break;
            case 7:
            enemigosTotales = aparecerEnemigoNVecer(3, 2);
            break;
            case 8:
            enemigosTotales = aparecerEnemigoNVecer(3, 2);
            break;
            case 9:
            enemigosTotales = aparecerEnemigoNVecer(3, 3);
            break;
            case 10:
            enemigosTotales = aparecerEnemigoNVecer(3, 3);
            break;
        }

    } 
    public int aparecerEnemigoNVecer(int n, int m){
        for(int i=0; i<n; i++){
            addObject(new Enemigo("E1"),Greenfoot.getRandomNumber(350)+200,Greenfoot.getRandomNumber(320)+40);  
        }
        for(int i=0; i<m; i++){
            addObject(new Enemigo("E2"),Greenfoot.getRandomNumber(350)+200,Greenfoot.getRandomNumber(320)+40);

        }
        return n+m;
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
