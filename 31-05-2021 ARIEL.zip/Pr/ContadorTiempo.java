import greenfoot.*;
import javax.swing.Timer;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ContadorTiempo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ContadorTiempo extends Actor
{
    /**
     * Act - do whatever the ContadorTiempo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private long createdMillis = System.currentTimeMillis();


    public ContadorTiempo(){
        
    }  
    
    public void act(){
        setImage(getAgeInSeconds() + ".png");
    }
    
    public int getAgeInSeconds() {
        long nowMillis = System.currentTimeMillis();
        return (int)((nowMillis - this.createdMillis) / 1000);
    }
    
}
