import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Door here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door extends Actor
{
    
    public Door(int AbiCerr, int posPuerta) // AbiCerr->Abierto "1" o Cerrado "0" , posPuerta->Posicion donde se encuentra la puerta a colocar Norte->0 Este->1 Sur->2 Oeste->3
    {
        switch(AbiCerr)
        {
            case 0: switch(posPuerta)
            {
                case 0: setImage("closed_up.png");
                break;
                case 1: setImage("closed_left.png");
                break;
                case 2: setImage("closed_down.png");
                break;
                case 3: setImage("closed_right.png");
                break;
            }
            break;
            case 1: switch(posPuerta)
            {
                case 0: setImage("Door_up.png");
                break;
                case 1: setImage("Door_left.png");
                break;
                case 2: setImage("Door_down.png");
                break;
                case 3: setImage("Door_right.png");
                break;
            }
            break;
        }
        
    }
    
}
