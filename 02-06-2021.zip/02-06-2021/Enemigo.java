import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 * Write a description of class enemigo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemigo extends Actor
{
    private int posicionJugador[] = {0,0};
    private int posicionEnemigo[] = {0,0};
    private int vida = 0;

    String nombre;
    
    /**
     * Act - do whatever the enemigo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
      
    public Enemigo(String nombre){
        this.nombre = nombre ; //Se asigna el String principal del nombre de la imagen del enemigo
        setImage(nombre + ".png"); // Se implementa la imagen .png
        this.vida = 3; //Se establecen las vidas iniciales del enemigo
    }
    
    public void act() 
    {
        followCharacter();
    }    
    
    public void followCharacter(){
        
        // Funcion para realizar el seguimiento al jugador principal (El enemigo debe de seguir al personaje principal)
        try{
        Jugador player = (Jugador) getWorld().getObjects(Jugador.class).get(0);
        
        if (player != null){
                
            for(int i = 0; i<2; i++){
               posicionJugador[0] = player.getX(); //Se guarda la posicion en X del jugador
               posicionJugador[1] = player.getY(); //Se guarda la posicion en Y del jugador
               posicionEnemigo[0] = getX(); //Se guarda la posicion en X del enemigo
               posicionEnemigo[1] = getY(); ////Se guarda la posicion en Y del enemigo
               if((Math.abs(posicionJugador[0]-posicionEnemigo[0])) > 20 ||  (Math.abs(posicionJugador[1]-posicionEnemigo[1])) > 20){ // Se analiza si el jugador se encuentra a distancia suficiente de los enemigos para que no le quiten vida .
                   if(posicionEnemigo[0]>posicionJugador[0]){
                   if(posicionEnemigo[1]>posicionJugador[1]){
                       setImage(nombre + "LEFT.png");
                       setLocation(getX()-1,getY()-1); //El enemigo se encuentra abajo a la derecha;
                   } else if(posicionEnemigo[1]<posicionJugador[1]){
                       setImage(nombre + "LEFT.png");
                       setLocation(getX()-1,getY()+1); //El enemigo se encuentra arriba a la derecha
                   } else {
                       setLocation(getX()-1,getY()); // El enemigo se encuentra a la derecha
                   }
               } else if(posicionEnemigo[0]<posicionJugador[0]){
                   if(posicionEnemigo[1]>posicionJugador[1]){
                       setImage(nombre + "RIGHT.png");
                       setLocation(getX()+1,getY()-1); //El enemigo se encuentra abajo a la izquierda;
                   } else if(posicionEnemigo[1]<posicionJugador[1]){
                       setImage(nombre + "RIGHT.png");
                       setLocation(getX()+1,getY()+1); //El enemigo se encuentra arriba a la izquierda
                   } else {
                       setLocation(getX()+1,getY()); //El enemigo se encuentra a la izquierda
                   }
               } else if(posicionEnemigo[0]==posicionJugador[0]){
                   if(posicionEnemigo[1]>posicionJugador[1]){
                       setImage(nombre + "UP.png");
                       setLocation(getX(),getY()-1); //El enemigo se encuentra abajo a la izquierda;
                   } else if(posicionEnemigo[1]<posicionJugador[1]){
                       setImage(nombre + ".png");
                       setLocation(getX(),getY()+1); //El enemigo se encuentra arriba a la izquierda
                   } else {
                       player.diminuyeVidaJugador();
                   }
               }
                   
               } else {
               player.diminuyeVidaJugador();
              }
            }
        }        
        } catch(Exception e){
            return;
        }
        
    }
    
 public void diminuyeVida()
 {
    if(vida <=1){
        ((Nivel)getWorld()).decrementarEnemigos();
        getWorld().removeObject(this);
    } 
    
    vida--;
    
    
    //Si un enemigo toca al jugador, se le disminuye la vida en 20;
    
    // Si la vida es menor o igual a 0, entonces se elimina el objeto y acaba el juego. 
    
    //TODO: Regresar al menu principal.
    
 }
 
 public int getVida(){
     return vida;
 }
}



