/**
 * Funciona similarmente al codigo otorgado por el profesor en el parcial 3. 
 * Representa / contiene los diferentes cuartos del nivel correspondiente 
 * @author (Hernandez Dean) 
 * @version (0.10 01/06/2021)
 */
public class Room  
{
    // instance variables - replace the example below with your own
    public int nivel; //Nivel al que pertenece
    public int RoomID; //Numero de cuarto
    public boolean TieneEnemigos;
    public Room northExit;
    public Room southExit;
    public Room eastExit;
    public Room westExit;
    
  
    /**
     * Constructor for objects of class Room
     */
    public Room(int nivel, int RoomID)
    {
        this.nivel = nivel;
        this.RoomID = RoomID;
        this.TieneEnemigos = true;
    }

    
    /**
     * Definir las salidas del cuarto. Cada direccion te lleva a un cuarto diferente o no existe
     * @param north The north exit.
     * @param east The east east.
     * @param south The south exit.
     * @param west The west exit.
     */
    public void setExits(Room north, Room east, Room south, Room west) 
    {
        if(north != null) {
            northExit = north;
        }
        if(east != null) {
            eastExit = east;
        }
        if(south != null) {
            southExit = south;
        }
        if(west != null) {
            westExit = west;
        }
    }
    
    /*
    public void PrintRoomInfo()
    {
        System.out.println("El ID de este cuarto es el: "+RoomID);
        System.out.println("Este cuarto pertenece al nivel: "+nivel);
    }
    */
    
}
