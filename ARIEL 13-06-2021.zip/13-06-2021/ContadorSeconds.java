import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class contadorSeconds here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ContadorSeconds extends ContadorTiempo
{
    /**
     * Act - do whatever the contadorSeconds wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public ContadorSeconds(){
    
    }
    
    public void act() 
    {
       setImage(getAgeInSeconds()%10 + ".png");
       // Add your action code here.
    }    
}
