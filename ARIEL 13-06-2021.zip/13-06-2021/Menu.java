import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{
private GreenfootSound soundtrack = new GreenfootSound("MMenu.mp3"); 
    /**
     * Constructor for objects of class Menu.
     * 
     */
    public Menu()
    {    
      // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
      super(1200, 800, 1, false); 
      prepare();
    }
    

    private void prepare()
    {
        GreenfootImage logo = new GreenfootImage("DEUS-EX-MACHINA-MAN.png");
        Logo l = new Logo(logo);
        addObject(l,getWidth()/2,150);
        JUGAR jugar = new JUGAR();
        addObject(jugar,589,444);
        INSTRUCCIONS instruccions = new INSTRUCCIONS();
        addObject(instruccions,565,568);
        instruccions.setLocation(615,542);
        SALIR salir = new SALIR();
        addObject(salir,595,674);
    }
    public void started()
    {
        soundtrack.play();
    }
    public void stopped()
    {
        soundtrack.stop();
    }
}
