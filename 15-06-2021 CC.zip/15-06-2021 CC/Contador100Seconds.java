import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Contador100Seconds here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Contador100Seconds extends ContadorTiempo
{
    /**
     * Act - do whatever the Contador100Seconds wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Contador100Seconds(){
    
    }
    
    public void act() 
    {
        setImage((getAgeInSeconds()/100)%10 + ".png");// Add your action code here.
    }    
}
