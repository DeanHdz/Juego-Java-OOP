import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class levelcomplete here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class levelcomplete extends World
{
private GreenfootSound level = new GreenfootSound("level passed theme.mp3"); 
    /**
     * Constructor for objects of class levelcomplete.
     * 
     */
    public levelcomplete()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(650, 400, 1); 
    }
    public void started()
    {
        level.play();
    }
    public void stopped()
    {
        level.stop();
    }
}
