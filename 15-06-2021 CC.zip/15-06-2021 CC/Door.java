import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Door here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door extends Actor
{
    int direccionPuerta;
    int Estado; // Abierto <- 1 Cerrado <- 0
    
    public void act()
    {
    CollisionJugador();
    }
    
    public Door(int AbiCerr, int posPuerta) // AbiCerr->Abierto "1" o Cerrado "0" , posPuerta->Posicion donde se encuentra la puerta a colocar Norte->0 Este->1 Sur->2 Oeste->3
    {
        switch(AbiCerr)
        {
            case 0: Estado = 0;
            switch(posPuerta)
            {
                case 0: setImage("closed_up.png");
                this.direccionPuerta=0;
                break;
                case 1: setImage("closed_left.png");
                this.direccionPuerta=1;
                break;
                case 2: setImage("closed_down.png");
                this.direccionPuerta=2;
                break;
                case 3: setImage("closed_right.png");
                this.direccionPuerta=3;
                break;
            }
            break;
            case 1: Estado = 1;
            switch(posPuerta)
            {
                case 0: setImage("Door_up.png");
                this.direccionPuerta=0;
                break;
                case 1: setImage("Door_left.png");
                this.direccionPuerta=1;
                break;
                case 2: setImage("Door_down.png");
                this.direccionPuerta=2;
                break;
                case 3: setImage("Door_right.png");
                this.direccionPuerta=3;
                break;
            }
            break;
        }
        
    }
    
    public void CollisionJugador(){
        if(Estado == 1){
        Jugador P = (Jugador)getOneIntersectingObject(Jugador.class);
        if(P != null && ((Math.abs(P.getX()-this.getX())<80)&&(Math.abs(P.getX()-this.getX())>0)) && ((Math.abs(P.getY()-this.getY())<80)&&(Math.abs(P.getY()-this.getY())>0)))
        {
         Jugador player = (Jugador) getWorld().getObjects(Jugador.class).get(0);
         player.setLocation(50,50);
         World w = getWorld();
         Room r = new Room();
         switch(direccionPuerta)
         {
             case 0: r = ((Nivel)w).getCR_north();
            ((Nivel)w).cambiarRoom(r);
             break;
             case 1: r = ((Nivel)w).getCR_east();
            ((Nivel)w).cambiarRoom(r);
            break;
            case 2: r = ((Nivel)w).getCR_south();
            ((Nivel)w).cambiarRoom(r);
            break;
            case 3: r = ((Nivel)w).getCR_west();
            ((Nivel)w).cambiarRoom(r);
            break;
         }
        }
    }
      
    }
    
}